package hashcode;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by bruno on 3/1/2018.
 */

public class OutputTest {

    @Test
    public void test1() {
        assertTrue(true);
    }
}
