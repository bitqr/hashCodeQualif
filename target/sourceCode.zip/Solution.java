/**
 * Created by Abdel on 01/03/2018.
 */
public class Solution {

    ProblemInstance instance;

    public Solution(ProblemInstance instance){
        this.instance = instance;
    }

    public String toString(){
        StringBuilder str = new StringBuilder();
        return str.toString();
    }

    public void write(){

    }

    public void readInitialSolution(String fileName){

    }

    public double evaluate(){
        double value=0.0;

        return value;
    }
}
